# Assignment: Mini-MEAN store

Create a RESTful API using Express and get this to pull/update/delete records from the database!
